import sys,urllib2
ruta = "http://127.0.0.1:4244/" + sys.argv[1]
urllib2.urlopen(ruta).read()